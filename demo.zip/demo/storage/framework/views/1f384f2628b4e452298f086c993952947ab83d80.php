<?php $__env->startSection('title','Add New hospital'); ?>

<?php $__env->startSection('body'); ?>

    <div class="container">
      <?php if(Session::has('hospital_save')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(Session::get('hospital_save')); ?>

        </div>
      <?php endif; ?>
      <form action="<?php echo e(route('hospital.save')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Hospital Name</label>
            <input type="text" name="hospital_name" class="form-control" id="" placeholder="Enter hospital Name" >
            <?php $__errorArgs = ['hospital_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

           <div class="form-group col-md-6">
            <label for="inputPassword4"> Department Name</label>
              <select name="dept_id" id="">
                <option value="">-Select Department-</option>
                  <?php if(isset($departments) && $departments != null): ?>
                      <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </select>
          </div>

        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
  </diV>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('hospital.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\demo\resources\views/hospital/add-hospital.blade.php ENDPATH**/ ?>