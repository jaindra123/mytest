<?php $__env->startSection('title','Post List'); ?>
<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row" >
           <form action="<?php echo e(route('patient.search')); ?>" method="GET" style="margin-top: 20px;">
               <input type="text" name="search_key" class="form-control" id="" placeholder="Email" >
                <input type="text" name="contact_key" class="form-control" id="" placeholder="Contact" >
                <input type="submit" class="btn btn-danger btn-sm" value="Filter">
            </form>
           
            <table class="table table-bordered" id="resultData">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Hospital Name</th>
                    <th>Department Name</th>
                  </tr>
                </thead> 
                <tbody>
                    <?php if(isset($patients) && $patients != null): ?>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($patient->id); ?></td>
                            <td><?php echo e($patient->p_name); ?></td>
                            <td><?php echo e($patient->p_email); ?></td>
                            <td><?php echo e($patient->p_contact); ?></td>
                            <td><?php echo e($patient->hospital_name); ?></td>
                            <td><?php echo e($patient->dept_name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
         </div>
    </div>
    <style type="text/css">
        #indeximg{
            height:80px;
            width:80px;
        }
    </style>


   <!--  <script src="http://demo.expertphp.in/js/jquery.js"></script>
    <script src="http://demo.expertphp.in/js/jquery-ui.min.js"></script>
    <link href="http://demo.expertphp.in/css/jquery.ui.autocomplete.css" rel="stylesheet">

    <script type="text/javascript">
        var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
        jQuery(document).ready(function(){
            jQuery( "#blog_search" ).autocomplete({
                source: function( request, response ) {
                  jQuery.ajax({
                    url:"<?php echo e(route('patient.search')); ?>",
                    type: 'post',
                    dataType: "json",
                    data: {
                       _token: CSRF_TOKEN,
                       search: request.term
                    },
                    success: function( data ) {
                       response( data );
                    }
                  });
                },
                select: function (event, ui) {
                   jQuery('#blog_search').val(ui.item.label); 
                   jQuery('#blogid').val(ui.item.value); 
                   return false;
                }
            });
        });
    </script>  -->
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\demo\resources\views/patient/patients.blade.php ENDPATH**/ ?>