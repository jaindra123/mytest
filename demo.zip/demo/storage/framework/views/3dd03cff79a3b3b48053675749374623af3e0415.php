<?php $__env->startSection('title','Post List'); ?>
<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="row" >

            <table class="table table-bordered" id="resultData">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Department Name</th>
                  </tr>
                </thead> 
                <tbody>
                    <?php if(isset($departments) && $departments != null): ?>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($department->id); ?></td>
                            <td><?php echo e($department->dept_name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
         </div>
    </div>
    <style type="text/css">
        #indeximg{
            height:80px;
            width:80px;
        }
    </style>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('department.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\demo\resources\views/department/departments.blade.php ENDPATH**/ ?>